# Lokoshilpo – storefront

Files: index.html (the whole site) + store.json (products and settings). No build step, no database.

## Go live (Vercel)
1. Upload this folder to Vercel (drag & drop, or via GitHub). Add the domain lokoshilpo.com in Project > Domains.

## Manage the store
1. Open https://lokoshilpo.com/#admin (or the "Manage store" footer link).
2. Add/edit products, upload photos, set WhatsApp number, shipping and USD rate.
3. Open the Publish tab > Download store.json > replace the file in this folder and redeploy.
   (Edits are saved only in your own browser until you do this.)

## Important first step
Open store.json and change "wa" to your real WhatsApp number (country code, no +, e.g. 8801XXXXXXXXX) and "email".

## How orders work
Checkout builds the order and opens a ready-made WhatsApp / email message to you. You confirm payment and delivery with the customer. There is no online card payment built in.
